<?php
    $conn = mysqli_connect('localhost','root','','saffa') or die('gagal konek');
